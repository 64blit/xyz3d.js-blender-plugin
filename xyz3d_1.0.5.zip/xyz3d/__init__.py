# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "xyz3d",
    "author" : "64blit", 
    "description" : "xyz3d helper addon that sets the selected objects custom properties and allows for easy importing and exporting",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 5),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Import-Export" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
operations = {'sna_selected': None, 'sna_properties': [], }


def sna_setpropertydataandtarget_805E1(layout_function, label, name, value, icon):
    box_1B8E1 = layout_function.box()
    box_1B8E1.alert = False
    box_1B8E1.enabled = True
    box_1B8E1.active = True
    box_1B8E1.use_property_split = False
    box_1B8E1.use_property_decorate = False
    box_1B8E1.alignment = 'Left'.upper()
    box_1B8E1.scale_x = 0.550000011920929
    box_1B8E1.scale_y = 1.0
    if not True: box_1B8E1.operator_context = "EXEC_DEFAULT"
    split_1DDE0 = box_1B8E1.split(factor=0.7666666507720947, align=False)
    split_1DDE0.alert = False
    split_1DDE0.enabled = True
    split_1DDE0.active = True
    split_1DDE0.use_property_split = False
    split_1DDE0.use_property_decorate = False
    split_1DDE0.scale_x = 1.0
    split_1DDE0.scale_y = 1.0
    split_1DDE0.alignment = 'Expand'.upper()
    if not True: split_1DDE0.operator_context = "EXEC_DEFAULT"
    split_1DDE0.label(text='Set ' + label, icon_value=icon)
    op = split_1DDE0.operator('sna.set_custom_property_with_target_active_1ce39', text='Apply', icon_value=9, emboss=True, depress=False)
    op.sna_prop_name = name
    op.sna_prop_data = value


def sna_setpropertydata_B68AB(layout_function, label, name, value, icon):
    box_03CF2 = layout_function.box()
    box_03CF2.alert = False
    box_03CF2.enabled = True
    box_03CF2.active = True
    box_03CF2.use_property_split = False
    box_03CF2.use_property_decorate = False
    box_03CF2.alignment = 'Left'.upper()
    box_03CF2.scale_x = 0.550000011920929
    box_03CF2.scale_y = 1.0
    if not True: box_03CF2.operator_context = "EXEC_DEFAULT"
    split_665CD = box_03CF2.split(factor=0.7666666507720947, align=False)
    split_665CD.alert = False
    split_665CD.enabled = True
    split_665CD.active = True
    split_665CD.use_property_split = False
    split_665CD.use_property_decorate = False
    split_665CD.scale_x = 1.0
    split_665CD.scale_y = 1.0
    split_665CD.alignment = 'Expand'.upper()
    if not True: split_665CD.operator_context = "EXEC_DEFAULT"
    split_665CD.label(text='Set ' + label, icon_value=icon)
    op = split_665CD.operator('sna.set_custom_property_c600c', text='Apply', icon_value=9, emboss=True, depress=False)
    op.sna_prop_name = name
    op.sna_prop_data = value


def sna_showproperty_4EFBE(layout_function, name, property):
    if property in bpy.context.view_layer.objects.active:
        split_387A0 = layout_function.split(factor=0.7888889312744141, align=False)
        split_387A0.alert = False
        split_387A0.enabled = True
        split_387A0.active = (len(bpy.context.view_layer.objects.active[property]) > round(0.0, abs(0)))
        split_387A0.use_property_split = False
        split_387A0.use_property_decorate = False
        split_387A0.scale_x = 1.0
        split_387A0.scale_y = 1.0
        split_387A0.alignment = 'Expand'.upper()
        if not True: split_387A0.operator_context = "EXEC_DEFAULT"
        split_387A0.label(text=name + bpy.context.view_layer.objects.active[property], icon_value=0)
        op = split_387A0.operator('sna.set_custom_property_c600c', text='Delete', icon_value=21, emboss=True, depress=False)
        op.sna_prop_name = property
        op.sna_prop_data = ''


def sna_addproperty_A1F3A(layout_function, label, name, value, icon):
    box_0FCB4 = layout_function.box()
    box_0FCB4.alert = False
    box_0FCB4.enabled = True
    box_0FCB4.active = True
    box_0FCB4.use_property_split = False
    box_0FCB4.use_property_decorate = False
    box_0FCB4.alignment = 'Left'.upper()
    box_0FCB4.scale_x = 0.550000011920929
    box_0FCB4.scale_y = 1.0
    if not True: box_0FCB4.operator_context = "EXEC_DEFAULT"
    split_61E18 = box_0FCB4.split(factor=0.7666666507720947, align=False)
    split_61E18.alert = False
    split_61E18.enabled = True
    split_61E18.active = True
    split_61E18.use_property_split = False
    split_61E18.use_property_decorate = False
    split_61E18.scale_x = 1.0
    split_61E18.scale_y = 1.0
    split_61E18.alignment = 'Expand'.upper()
    if not True: split_61E18.operator_context = "EXEC_DEFAULT"
    split_61E18.label(text='Set ' + label, icon_value=icon)
    op = split_61E18.operator('sna.set_custom_property_c600c', text='Apply', icon_value=9, emboss=True, depress=False)
    op.sna_prop_name = name
    op.sna_prop_data = value


class SNA_PT_XYZ3D_65C4E(bpy.types.Panel):
    bl_label = 'xyz3d'
    bl_idname = 'SNA_PT_XYZ3D_65C4E'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'xyz3d'
    bl_order = 999
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_0D7D0 = layout.box()
        box_0D7D0.alert = False
        box_0D7D0.enabled = True
        box_0D7D0.active = True
        box_0D7D0.use_property_split = False
        box_0D7D0.use_property_decorate = False
        box_0D7D0.alignment = 'Expand'.upper()
        box_0D7D0.scale_x = 1.0
        box_0D7D0.scale_y = 1.0
        if not True: box_0D7D0.operator_context = "EXEC_DEFAULT"
        box_0D7D0.prop(bpy.context.scene, 'sna_zone', text='Scene Zone', icon_value=240, emboss=True)
        box_F515E = box_0D7D0.box()
        box_F515E.alert = False
        box_F515E.enabled = True
        box_F515E.active = True
        box_F515E.use_property_split = False
        box_F515E.use_property_decorate = False
        box_F515E.alignment = 'Expand'.upper()
        box_F515E.scale_x = 1.0
        box_F515E.scale_y = 1.0
        if not True: box_F515E.operator_context = "EXEC_DEFAULT"
        split_2A209 = box_F515E.split(factor=0.2944444417953491, align=False)
        split_2A209.alert = False
        split_2A209.enabled = True
        split_2A209.active = True
        split_2A209.use_property_split = False
        split_2A209.use_property_decorate = False
        split_2A209.scale_x = 1.0
        split_2A209.scale_y = 1.0
        split_2A209.alignment = 'Expand'.upper()
        if not True: split_2A209.operator_context = "EXEC_DEFAULT"
        split_2A209.prop(bpy.context.scene, 'sna_zoneindex', text='Index', icon_value=0, emboss=True)
        layout_function = split_2A209
        sna_setpropertydata_B68AB(layout_function, 'Scene Zone Index (' + str(bpy.context.scene.sna_zoneindex) + ')', 'index', str(bpy.context.scene.sna_zoneindex), 745)
        layout_function = box_F515E
        sna_setpropertydata_B68AB(layout_function, 'Scene Zone (' + bpy.context.scene.sna_zone + ')', 'zone', bpy.context.scene.sna_zone, 482)
        box_37C4B = box_0D7D0.box()
        box_37C4B.alert = False
        box_37C4B.enabled = True
        box_37C4B.active = True
        box_37C4B.use_property_split = False
        box_37C4B.use_property_decorate = False
        box_37C4B.alignment = 'Expand'.upper()
        box_37C4B.scale_x = 1.0
        box_37C4B.scale_y = 1.0
        if not True: box_37C4B.operator_context = "EXEC_DEFAULT"
        box_37C4B.label(text='Models', icon_value=0)
        layout_function = box_37C4B
        sna_setpropertydata_B68AB(layout_function, 'Camera Bounds', 'type', 'cameraBounds', 240)
        layout_function = box_37C4B
        sna_setpropertydata_B68AB(layout_function, 'Background Mesh', 'type', 'bgMesh', 583)
        split_D5F80 = box_37C4B.split(factor=0.5, align=False)
        split_D5F80.alert = False
        split_D5F80.enabled = True
        split_D5F80.active = True
        split_D5F80.use_property_split = False
        split_D5F80.use_property_decorate = False
        split_D5F80.scale_x = 1.0
        split_D5F80.scale_y = 1.0
        split_D5F80.alignment = 'Expand'.upper()
        if not True: split_D5F80.operator_context = "EXEC_DEFAULT"
        layout_function = split_D5F80
        sna_setpropertydata_B68AB(layout_function, 'Interactable', 'type', 'interactable', 208)
        layout_function = split_D5F80
        sna_setpropertydataandtarget_805E1(layout_function, 'Raycast Mesh', 'type', 'raycastMesh', 551)
        box_05EEE = box_37C4B.box()
        box_05EEE.alert = False
        box_05EEE.enabled = True
        box_05EEE.active = True
        box_05EEE.use_property_split = False
        box_05EEE.use_property_decorate = False
        box_05EEE.alignment = 'Expand'.upper()
        box_05EEE.scale_x = 1.0
        box_05EEE.scale_y = 1.0
        if not True: box_05EEE.operator_context = "EXEC_DEFAULT"
        box_05EEE.prop(bpy.context.scene, 'sna_action', text='Animation', icon_value=115, emboss=True)
        layout_function = box_05EEE
        sna_addproperty_A1F3A(layout_function, 'On Click Animations', 'onClickAnimations', bpy.context.scene.sna_action, 0)
        layout_function = box_05EEE
        sna_addproperty_A1F3A(layout_function, 'On Hover Animations', 'onHoverAnimations', bpy.context.scene.sna_action, 0)
        layout_function = box_05EEE
        sna_addproperty_A1F3A(layout_function, 'Looping Animations', 'loopAnimations', bpy.context.scene.sna_action, 0)
        layout_function = box_05EEE
        sna_addproperty_A1F3A(layout_function, 'Camera Animations', 'cameraAnimations', bpy.context.scene.sna_action, 0)
        box_D4705 = layout.box()
        box_D4705.alert = False
        box_D4705.enabled = True
        box_D4705.active = True
        box_D4705.use_property_split = False
        box_D4705.use_property_decorate = False
        box_D4705.alignment = 'Expand'.upper()
        box_D4705.scale_x = 1.0
        box_D4705.scale_y = 1.0
        if not True: box_D4705.operator_context = "EXEC_DEFAULT"
        box_06FB5 = box_D4705.box()
        box_06FB5.alert = False
        box_06FB5.enabled = True
        box_06FB5.active = True
        box_06FB5.use_property_split = False
        box_06FB5.use_property_decorate = False
        box_06FB5.alignment = 'Center'.upper()
        box_06FB5.scale_x = 1.0
        box_06FB5.scale_y = 1.0
        if not True: box_06FB5.operator_context = "EXEC_DEFAULT"
        split_16D59 = box_06FB5.split(factor=0.5, align=False)
        split_16D59.alert = False
        split_16D59.enabled = True
        split_16D59.active = True
        split_16D59.use_property_split = False
        split_16D59.use_property_decorate = False
        split_16D59.scale_x = 1.0
        split_16D59.scale_y = 1.0
        split_16D59.alignment = 'Expand'.upper()
        if not True: split_16D59.operator_context = "EXEC_DEFAULT"
        op = split_16D59.operator('view3d.view_camera', text='View Active Camera', icon_value=240, emboss=True, depress=False)
        op = split_16D59.operator('sna.selectall_40ef3', text='Select All', icon_value=385, emboss=True, depress=False)
        op = box_D4705.operator('export_scene.gltf', text='Export GLTF', icon_value=693, emboss=True, depress=False)


class SNA_PT_XYZ3D_6D735(bpy.types.Panel):
    bl_label = 'xyz3d'
    bl_idname = 'SNA_PT_XYZ3D_6D735'
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'xyz3d'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_OT_Set_Custom_Property_C600C(bpy.types.Operator):
    bl_idname = "sna.set_custom_property_c600c"
    bl_label = "Set Custom Property"
    bl_description = "Set Custom Property In World Tab"
    bl_options = {"REGISTER", "UNDO"}
    sna_prop_name: bpy.props.StringProperty(name='Prop Name', description='', default='', subtype='NONE', maxlen=0)
    sna_prop_data: bpy.props.StringProperty(name='Prop Data', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        for i_04F5A in range(len(bpy.context.view_layer.objects.selected)):
            bpy.context.view_layer.objects.selected[i_04F5A][self.sna_prop_name] = self.sna_prop_data
            print('location ', str(int(len(self.sna_prop_data) + 3.0)), str(tuple(getattr(bpy.context.view_layer.objects.selected[i_04F5A], 'location', None))))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Custom_Property_With_Target_Active_1Ce39(bpy.types.Operator):
    bl_idname = "sna.set_custom_property_with_target_active_1ce39"
    bl_label = "Set Custom Property With Target Active"
    bl_description = "Set Custom Property In World Tab"
    bl_options = {"REGISTER", "UNDO"}
    sna_prop_name: bpy.props.StringProperty(name='Prop Name', description='', default='', subtype='NONE', maxlen=0)
    sna_prop_data: bpy.props.StringProperty(name='Prop Data', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        for i_1019E in range(len(bpy.context.view_layer.objects.selected)):
            if (bpy.context.view_layer.objects.selected[i_1019E] != bpy.context.view_layer.objects.active):
                operations['sna_selected'] = bpy.context.view_layer.objects.selected[i_1019E]
        operations['sna_selected'][self.sna_prop_name] = self.sna_prop_data
        bpy.context.view_layer.objects.active['raycastTarget'] = operations['sna_selected'].name
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Clear_Custom_Properties_E0032(bpy.types.Operator):
    bl_idname = "sna.clear_custom_properties_e0032"
    bl_label = "Clear Custom Properties"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        for i_E1B63 in range(len(bpy.context.view_layer.objects.selected)):
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Selectall_40Ef3(bpy.types.Operator):
    bl_idname = "sna.selectall_40ef3"
    bl_label = "SelectAll"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.mode_set('INVOKE_DEFAULT', )
        bpy.ops.object.select_all('INVOKE_DEFAULT', action='SELECT')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Addtopropertieslist_1Feda(bpy.types.Operator):
    bl_idname = "sna.addtopropertieslist_1feda"
    bl_label = "AddToPropertiesList"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_propertytoadd: bpy.props.StringProperty(name='propertyToAdd', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (not self.sna_propertytoadd in []):
            operations['sna_properties'].append(self.sna_propertytoadd)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Copy_Action_Name_77C01(bpy.types.Operator):
    bl_idname = "sna.copy_action_name_77c01"
    bl_label = "Copy Action Name"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_action = None
        print('')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_EDIT_PROPERTIES_9CB9F(bpy.types.Panel):
    bl_label = 'Edit Properties'
    bl_idname = 'SNA_PT_EDIT_PROPERTIES_9CB9F'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_XYZ3D_65C4E'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_6F3CE = layout.box()
        box_6F3CE.alert = True
        box_6F3CE.enabled = True
        box_6F3CE.active = True
        box_6F3CE.use_property_split = False
        box_6F3CE.use_property_decorate = False
        box_6F3CE.alignment = 'Center'.upper()
        box_6F3CE.scale_x = 1.0
        box_6F3CE.scale_y = 1.0
        if not True: box_6F3CE.operator_context = "EXEC_DEFAULT"
        box_6F3CE.label(text=' Properties of: ' + getattr(bpy.context.view_layer.objects.active, 'name', None), icon_value=0)
        layout_function = box_6F3CE
        sna_showproperty_4EFBE(layout_function, 'Zone: ', 'zone')
        layout_function = box_6F3CE
        sna_showproperty_4EFBE(layout_function, 'Index: ', 'index')
        layout_function = box_6F3CE
        sna_showproperty_4EFBE(layout_function, 'Model Type: ', 'type')
        layout_function = box_6F3CE
        sna_showproperty_4EFBE(layout_function, 'Raycast Target: ', 'raycastTarget')
        layout_function = box_6F3CE
        sna_showproperty_4EFBE(layout_function, 'Click Animation: ', 'onClickAnimations')
        layout_function = box_6F3CE
        sna_showproperty_4EFBE(layout_function, 'Hover Animation: ', 'onHoverAnimations')
        layout_function = box_6F3CE
        sna_showproperty_4EFBE(layout_function, 'Camera Animation: ', 'cameraAnimations')
        layout_function = box_6F3CE
        sna_showproperty_4EFBE(layout_function, 'Loop Animation: ', 'loopAnimations')


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_zone = bpy.props.StringProperty(name='Zone', description='This is used for camera movement, in the 2d world of websites, this would be page name. This is usually: Home, About, Bio, Shop, etc ', default='ZoneNameHere', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_exportpath = bpy.props.StringProperty(name='ExportPath', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_zoneindex = bpy.props.IntProperty(name='ZoneIndex', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_action = bpy.props.StringProperty(name='Action', description='', default='ActionNameHere', subtype='NONE', maxlen=0)
    bpy.utils.register_class(SNA_PT_XYZ3D_65C4E)
    bpy.utils.register_class(SNA_PT_XYZ3D_6D735)
    bpy.utils.register_class(SNA_OT_Set_Custom_Property_C600C)
    bpy.utils.register_class(SNA_OT_Set_Custom_Property_With_Target_Active_1Ce39)
    bpy.utils.register_class(SNA_OT_Clear_Custom_Properties_E0032)
    bpy.utils.register_class(SNA_OT_Selectall_40Ef3)
    bpy.utils.register_class(SNA_OT_Addtopropertieslist_1Feda)
    bpy.utils.register_class(SNA_OT_Copy_Action_Name_77C01)
    bpy.utils.register_class(SNA_PT_EDIT_PROPERTIES_9CB9F)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_action
    del bpy.types.Scene.sna_zoneindex
    del bpy.types.Scene.sna_exportpath
    del bpy.types.Scene.sna_zone
    bpy.utils.unregister_class(SNA_PT_XYZ3D_65C4E)
    bpy.utils.unregister_class(SNA_PT_XYZ3D_6D735)
    bpy.utils.unregister_class(SNA_OT_Set_Custom_Property_C600C)
    bpy.utils.unregister_class(SNA_OT_Set_Custom_Property_With_Target_Active_1Ce39)
    bpy.utils.unregister_class(SNA_OT_Clear_Custom_Properties_E0032)
    bpy.utils.unregister_class(SNA_OT_Selectall_40Ef3)
    bpy.utils.unregister_class(SNA_OT_Addtopropertieslist_1Feda)
    bpy.utils.unregister_class(SNA_OT_Copy_Action_Name_77C01)
    bpy.utils.unregister_class(SNA_PT_EDIT_PROPERTIES_9CB9F)
